import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Dog1 extends JFrame
{
    String breed = "Shitzu";
    String tagnumber = "69";
    String color = "Rainbow";
    
    JTextField t1 = new JTextField("");
    JTextField t2 = new JTextField("");
    JTextField t3 = new JTextField("");
    
    JLabel l1 = new JLabel("Enter Dog Breed");
    JLabel l2 = new JLabel("Enter Tag Number");
    JLabel l3 = new JLabel("Enter Color");
    
    JButton enter = new JButton("Enter");
    public Dog1()
    {
        setTitle("Dog");
        setBounds(0,0,250,250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints gc = new GridBagConstraints();
        //gc.weightx = 1;
        //gc.weighty = 1;
        gc.fill = GridBagConstraints.BOTH;
        gc.insets = new Insets(5,5,5,5);
        gc.gridx = 0;
        gc.gridy = 0;
        getContentPane().add(l1,gc);
        gc.gridy = 1;
        getContentPane().add(l2,gc);
        gc.gridy = 2;
        getContentPane().add(l3,gc);
        gc.gridx = 1;
        gc.gridy = 0;
        t1.setColumns(5);
        getContentPane().add(t1,gc);
        gc.gridy = 1;
        t2.setColumns(5);
        getContentPane().add(t2,gc);
        gc.gridy = 2;
        t3.setColumns(5);
        getContentPane().add(t3,gc);
        gc.gridy = 3;
        gc.gridx = 0;
        gc.gridwidth = 3;
        gc.fill = GridBagConstraints.HORIZONTAL;
        getContentPane().add(enter,gc);
        enter.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                enterActionPerformed(e);
            }
        });
    }
    private void enterActionPerformed(ActionEvent e)
    {
        JFrame f;
        f = new JFrame();
        String bred = t1.getText();
        String tagnum = t2.getText();
        String colol = t3.getText();
        JOptionPane.showMessageDialog(f,"Dog Breed : " +bred + ", Tag No is : "+ tagnum + ", Color: " + colol ,"Thank You",JOptionPane.PLAIN_MESSAGE);
        System.exit(0);
    }
    public void printInfo()
    {
        System.out.println(breed+"\n"+tagnumber+"\n"+color);
    }
    
    public static void main(String[] args)
    {
        //Dog mydog = new Dog();
        new Dog1().show();
        //mydog.printInfo();
    }
}
