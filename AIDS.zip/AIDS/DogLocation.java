
public class DogLocation
{
    String location;
    
    public void getter()
    {
        
    }
}
