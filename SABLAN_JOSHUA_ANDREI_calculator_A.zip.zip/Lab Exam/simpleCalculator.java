import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class simpleCalculator extends JFrame implements ActionListener
{
    double num1,num2,answer;
    String calc,answer2;
    
    JLabel operand1 = new JLabel("Operand 1:");
    JLabel operator = new JLabel("Operator:");
    JLabel operand2 = new JLabel("Operand 2:");
    JLabel result = new JLabel("Result:");
    JLabel deez = new JLabel("");
    
    JTextField field1 = new JTextField("");
    JTextField field2 = new JTextField("");
    JTextField field3 = new JTextField("");
    JTextField field4 = new JTextField("");
    
    JButton calculate = new JButton("Calculate");
    JButton exit = new JButton("Exit");
    public simpleCalculator()
    {
        setTitle("Simple Calculator");
        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints gc = new GridBagConstraints();
        gc.weightx = 1;
        gc.weighty = 1;
        gc.insets = new Insets(7,7,7,7);
        gc.fill = GridBagConstraints.BOTH;
        gc.gridx = 0;
        gc.gridy = 0;
        getContentPane().add(operand1,gc);
        gc.gridy = 1;
        getContentPane().add(operator,gc);
        gc.gridy = 2;
        getContentPane().add(operand2,gc);
        gc.gridy = 3;
        getContentPane().add(result,gc);
        gc.gridx = 2;
        gc.gridy = 1;
        getContentPane().add(field2,gc);
        gc.gridy = 0;
        gc.gridwidth = 3;
        getContentPane().add(field1,gc);
        gc.gridy = 2;
        getContentPane().add(field3,gc);
        gc.gridy = 3;
        field4.setEditable(false);
        getContentPane().add(field4,gc);
        gc.gridy = 4;
        getContentPane().add(exit,gc);
        gc.gridwidth = 1;
        gc.gridx = 0;
        getContentPane().add(calculate,gc);
        gc.gridx = 3;
        gc.gridy = 3;
        gc.gridwidth = 2;
        getContentPane().add(deez,gc);
        addActionEvent();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
    }
    private void addActionEvent()
    {
        field1.addActionListener(this);
        field2.addActionListener(this);
        field3.addActionListener(this);
        calculate.addActionListener(this);
        exit.addActionListener(this);
    }
    public void actionPerformed(ActionEvent e)
    {
        Object source = e.getSource();
        if (source == calculate)
        {
            num1 = Double.parseDouble(field1.getText());
            num2 = Double.parseDouble(field3.getText());
            calc = field2.getText();
            if (calc.equals("+"))
            {
                answer = num1 + num2;
            } else if (calc.equals("-")) {
                answer = num1 - num2;
            } else if (calc.equals("*") || calc.equals("x")) {
                answer = num1 * num2;
            } else if (calc.equals("/")) {
                answer = num1 / num2;
            }
            field4.setText(answer+"");
        } else if (source == exit) {
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            System.exit(0);
        }
    }
    public static void main(String[] args)
    {
        new simpleCalculator().show();
    }
}
