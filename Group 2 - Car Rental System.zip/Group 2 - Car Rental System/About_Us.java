import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class About_Us extends JFrame
{
    JButton aids = new JButton("Press for free robux");
    JLabel title = new JLabel("About Us:",SwingConstants.CENTER);
    Container p = getContentPane();
    GridBagConstraints gc = new GridBagConstraints();
    
    ImageIcon card = new ImageIcon("D:/Group 2 - Car Rental System/Images/APerson.jpg");
    JLabel c1 = new JLabel(card);
    ImageIcon card1 = new ImageIcon("D:/Group 2 - Car Rental System/Images/APerson1.png");
    JLabel c2 = new JLabel(card1);
    ImageIcon card2 = new ImageIcon("D:/Group 2 - Car Rental System/Images/APerson2.jpg");
    JLabel c3 = new JLabel(card2);
    
    JButton back = new JButton("Back");
    JTextArea p1 = new JTextArea(6,25);
    JTextArea p2 = new JTextArea(6,25);
    JTextArea p3 = new JTextArea(6,25);
    JTextArea p0 = new JTextArea(6,25);
    public About_Us()
    {
        setTitle("Car Rental System");
        p.setLayout(new GridBagLayout());
        setBounds(0,0,550,700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        gc.fill = GridBagConstraints.BOTH;
        gc.insets = new Insets(5,5,5,5);
        gc.gridx = 1;
        gc.gridy = 0;
        title.setFont(title.getFont().deriveFont(35.0f));
        p.add(title,gc);
        gc.gridx = 0;
        gc.gridy = 1;
        p0.setEditable(false);
        p0.setFont(p0.getFont().deriveFont(20.0f));
        gc.gridwidth = 3;
        p0.setText("We are 2nd Yr. Students from Holy Angel University,\ncurrently working on this simple Car/Vehicle Rental\nProgram as our Finals Requirement for OOPLANG\n1st Semester. The following are members of said\nGroup 2.");
        p.add(p0,gc);
        gc.gridy = 2;
        gc.gridwidth = 1;
        p.add(c1,gc);
        gc.gridy = 3;
        p.add(c2,gc);
        gc.gridy = 4;
        p.add(c3,gc);
        gc.gridx = 1;
        gc.gridy = 5;
        p.add(back,gc);
        back.addActionListener(new ActionListener()
        {
        public void actionPerformed(ActionEvent e)
        {
        backActionPerformed(e);
        }
        });
        gc.gridy = 2;
        gc.gridwidth = 2;
        p1.setEditable(false);
        p1.setFont(p1.getFont().deriveFont(20.0f));
        p1.setText("Name: Anunciacion, Sean Timothy\nRole: Analyst, Documents ");
        p.add(p1,gc);
        gc.gridy = 3;
        p2.setEditable(false);
        p2.setFont(p2.getFont().deriveFont(20.0f));
        p2.setText("Name: Ramos, David Andre\nRole: Moral Support  Nangancer\nGod Among Men\nImmortal Peak Valorant Player");
        p.add(p2,gc);
        gc.gridy = 4;
        p3.setEditable(false);
        p3.setFont(p3.getFont().deriveFont(20.0f));
        p3.setText("Name: Sablan, Joshua Andrei\nRole: Head Coder \nPokemon Master");
        p.add(p3,gc);
    }
    private void backActionPerformed(ActionEvent e)
    {
        this.dispose();
        new UI().show();
    }
}
