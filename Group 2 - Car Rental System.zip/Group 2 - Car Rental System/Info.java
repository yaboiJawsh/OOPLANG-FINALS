public class Info
{
    public String name, contact, pLoc, dLoc;
    int fDay, tDay, total;
    public Info()
    {
        name = ""; 
        contact = ""; 
        pLoc = ""; 
        dLoc = "";
        fDay = 0;
        tDay = 0;
        total = 0;
    }
    public void setInfo(String n, String c, String pL, String dL, int fD, int tD, int tot)
    {
        name = n;
        contact = c;
        pLoc = pL;
        dLoc = dL;
        fDay = fD;
        tDay = tD;
        total = tot;
    }
    public String getName()
    {
        return name;
    }
    public String getContact()
    {
        return contact;
    }
    public String getPLoc()
    {
        return pLoc;
    }
    public String getDLoc()
    {
        return dLoc;
    }
    public int getTDay()
    {
        return tDay;
    }
    public int getFDay()
    {
        return fDay;
    }
    public int getTotal()
    {
        return getFDay()-getTDay();
    }
}
