import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Locations extends JFrame
{
    JButton aids = new JButton("Press for free robux");
    JLabel title = new JLabel("Locations:",SwingConstants.CENTER);
    Container p = getContentPane();
    GridBagConstraints gc = new GridBagConstraints();
    
    ImageIcon card = new ImageIcon("D:/Group 2 - Car Rental System/Images/Loc1.png");
    JLabel c1 = new JLabel(card);
    ImageIcon card1 = new ImageIcon("D:/Group 2 - Car Rental System/Images/Loc2.jpg");
    JLabel c2 = new JLabel(card1);
    ImageIcon card2 = new ImageIcon("D:/Group 2 - Car Rental System/Images/Loc3.jpg");
    JLabel c3 = new JLabel(card2);
    JButton back = new JButton("Back");
    
    JLabel locDetails = new JLabel("Ryongsong Residence, North Korea",SwingConstants.CENTER);
    JLabel locDetails1 = new JLabel("Tondo Manila, Philippines",SwingConstants.CENTER);
    JLabel locDetails2 = new JLabel("Mushroom Kingdom, Super Mario Bros.",SwingConstants.CENTER);
    public Locations()
    {
        setTitle("Car Rental System");
        p.setLayout(new GridBagLayout());
        setBounds(0,0,1000,500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        gc.fill = GridBagConstraints.BOTH;
        gc.insets = new Insets(5,5,5,5);
        gc.gridx = 1;
        gc.gridy = 0;
        title.setFont(title.getFont().deriveFont(35.0f));
        p.add(title,gc);
        gc.gridx = 0;
        gc.gridy = 1;
        p.add(c1,gc);
        gc.gridx = 1;
        p.add(c2,gc);
        gc.gridx = 2;
        p.add(c3,gc);
        gc.gridx = 1;
        gc.gridy = 3;
        p.add(back,gc);
        back.addActionListener(new ActionListener()
        {
        public void actionPerformed(ActionEvent e)
        {
        backActionPerformed(e);
        }
        });
        gc.gridx = 0;
        gc.gridy = 2;
        p.add(locDetails,gc);
        gc.gridx = 1;
        p.add(locDetails1,gc);
        gc.gridx = 2;
        p.add(locDetails2,gc);
    }
    private void backActionPerformed(ActionEvent e)
    {
        this.dispose();
        new UI().show();
    }
}
