import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Rent extends JFrame implements ActionListener
{
    JLabel title = new JLabel("Rental Information:",SwingConstants.CENTER);
    JLabel cars = new JLabel("Cars for Rent",SwingConstants.CENTER);
    Container p = getContentPane();
    GridBagConstraints gc = new GridBagConstraints();
    
    JLabel pickup = new JLabel("Picking Up");
    JLabel dropoff = new JLabel("Dropping Off");
    JLabel pMonth = new JLabel("Pickup Month");
    JLabel pDay = new JLabel("Pickup Day");
    JLabel rMonth = new JLabel("Return Month");
    JLabel rDay = new JLabel("Return Day");
    JLabel nameL = new JLabel("Enter Full Name (First, MI, Last):");
    JLabel contactL = new JLabel("Enter Contact Number:");
    JLabel s1 = new JLabel("",SwingConstants.CENTER);
    JLabel s2 = new JLabel("",SwingConstants.CENTER);
    JLabel s3 = new JLabel("",SwingConstants.CENTER);
    JLabel s4 = new JLabel("",SwingConstants.CENTER);
    
    ImageIcon bard = new ImageIcon("D:/Group 2 - Car Rental System/Images/Car1.jpg");
    JButton b1 = new JButton(bard);
    ImageIcon bard1 = new ImageIcon("D:/Group 2 - Car Rental System/Images/Car5.jpg");
    JButton b2 = new JButton(bard1);
    ImageIcon bard2 = new ImageIcon("D:/Group 2 - Car Rental System/Images/Car7.jpg");
    JButton b3 = new JButton(bard2);
    ImageIcon bard3 = new ImageIcon("D:/Group 2 - Car Rental System/Images/Car8.jpg");
    JButton b4 = new JButton(bard3);
    
    JTextField name = new JTextField("");
    JTextField contacts = new JTextField("");
    
    String[] pLoc = {"Choose a Department","Pyongyang Department","Tondo Department","Mushroom Kingdom Department"};
    String[] dLoc = {"Choose a Department","Pyongyang Department","Tondo Department","Mushroom Kingdom Department"};
    String[] month = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    Integer[] day = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31};
    
    ImageIcon card = new ImageIcon("D:/Group 2 - Car Rental System/Images/Back1.jpg");
    JButton back = new JButton(card);
    ImageIcon card1 = new ImageIcon("D:/Group 2 - Car Rental System/Images/Next.jpg");
    JButton next = new JButton(card1);
    
    JComboBox<String> cb = new JComboBox<String>(pLoc);
    JComboBox<String> cb1 = new JComboBox<String>(dLoc);
    JComboBox<String> cb2 = new JComboBox<String>(month);
    JComboBox<Integer> cb3 = new JComboBox<Integer>(day);
    JComboBox<String> cb4 = new JComboBox<String>(month);
    JComboBox<Integer> cb5 = new JComboBox<Integer>(day);
    JTextArea carDetails = new JTextArea(7,25);
    
    final static int MONTH_DAYS = 30, MONTHS = 12;
    String a,b,c,d,g,hiv,model = "";
    int days,days2,tDays = 0,fDays = 0,h = 0,z = 0,total =0, rate = 0,total_fee;
    Info infos = new Info();
    
    public Rent()
    {
        setTitle("Car Rental System");
        p.setLayout(new GridBagLayout());
        setBounds(0,0,1200,500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        gc.fill = GridBagConstraints.BOTH;
        gc.insets = new Insets(5,5,5,5);
        gc.gridx = 0;
        gc.gridy = 0;
        gc.gridwidth = 2;
        title.setFont(title.getFont().deriveFont(35.0f));
        p.add(title,gc);
        gc.gridx = 2;
        gc.gridwidth = 4;
        cars.setFont(title.getFont().deriveFont(35.0f));
        p.add(cars,gc);
        gc.gridx = 0;
        gc.gridwidth = 1;
        gc.gridy = 2;
        p.add(cb,gc);
        gc.gridx = 1;
        p.add(cb1,gc);
        gc.gridx = 0;
        gc.gridy = 1;
        p.add(pickup,gc);
        gc.gridx = 1;
        p.add(dropoff,gc);
        gc.gridx = 0;
        gc.gridy = 4;
        p.add(cb2,gc);
        gc.gridx = 1;
        p.add(cb3,gc);
        gc.gridy = 3;
        p.add(pDay,gc);
        gc.gridx = 0;
        p.add(pMonth,gc);
        gc.gridy = 5;
        p.add(rMonth,gc);
        gc.gridx = 1;
        p.add(rDay,gc);
        gc.gridy = 6;
        p.add(cb5,gc);
        gc.gridx = 0;
        p.add(cb4,gc);
        gc.gridy = 7;
        p.add(nameL,gc);
        gc.gridx = 1;
        p.add(contactL,gc);
        gc.gridy = 8;
        p.add(contacts,gc);
        gc.gridx = 0;
        p.add(name,gc);
        gc.gridy = 10;
        p.add(back,gc);
        gc.gridx = 1;
        p.add(next,gc);
        gc.gridheight = 3;
        gc.gridx = 2;
        gc.gridy = 2;
        p.add(b1,gc);
        gc.gridy = 6;
        p.add(b3,gc);
        gc.gridx = 4;
        gc.gridy = 2;
        p.add(b2,gc);
        gc.gridy = 6;
        p.add(b4,gc);
        gc.gridx = 7;
        gc.gridy = 2;
        carDetails.setEditable(false);
        carDetails.setText("Click on a Car\nfor more Details");
        p.add(carDetails,gc);
        addActionEvent();
    }
    private void addActionEvent()
    {
        back.addActionListener(this);
        next.addActionListener(this);
        cb.addActionListener(this);
        cb1.addActionListener(this);
        cb2.addActionListener(this);
        cb3.addActionListener(this);
        cb4.addActionListener(this);
        cb5.addActionListener(this);
        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);
        b4.addActionListener(this);
    }
    public void actionPerformed(ActionEvent e) 
    {   
        Object source = e.getSource();
        JFrame f;
        f = new JFrame();
        if (source == back)
        {
            this.dispose();
            new UI().show();
        }   else if (source == b1)
        {
            model = "Mitsubishi 3000 GT";
            rate = 6942;
            carDetails.setText("Selected: Mitsubishi 3000GT\nLightning McQueen Edtn.\nRate: Php 6942.0");
        } else if (source == b2)
        {
            model = "Mazda CX-5";
            rate = 4400;
            carDetails.setText("Selected: Mazda CX-5\nRate: Php 4400");
        } else if (source == b3)
        {
            model = "Chevrolet Express";
            rate = 5000;
            carDetails.setText("Selected: Chevrolet Express\nRate: Php 5000");
        } else if (source == b4)
        {
            model = "Honda Ridgeline Sport";
            rate = 3750;
            carDetails.setText("Selected: Honda Ridgeline Sport\nRate: Php 3750");
        } else if (source == next)
        {
            a = (String) cb.getSelectedItem();
            b = (String) cb1.getSelectedItem();
            if (a.equals("Choose a Department") | b.equals("Choose a Department"))
            {
                z +=1;
                JOptionPane.showMessageDialog(null,"Please Select a Department","Error",JOptionPane.WARNING_MESSAGE);
            }
            days = (int) cb3.getSelectedItem();
            c = (String) cb2.getSelectedItem();
            switch(c)
            {
                case "Jan":
                    tDays = 0*MONTH_DAYS+days;
                    break;
                case "Feb":
                    tDays = 1*MONTH_DAYS+days;
                    break;
                case "Mar":
                    tDays = 2*MONTH_DAYS+days;
                    break;
                case "Apr":
                    tDays = 3*MONTH_DAYS+days;
                    break;
                case "May":
                    tDays = 4*MONTH_DAYS+days;
                    break;
                case "Jun":
                    tDays = 5*MONTH_DAYS+days;
                    break;
                case "Jul":
                    tDays = 6*MONTH_DAYS+days;
                    break;
                case "Aug":
                    tDays = 7*MONTH_DAYS+days;
                    break;
                case "Sep":
                    tDays = 8*MONTH_DAYS+days;
                    break;
                case "Oct":
                    tDays = 9*MONTH_DAYS+days;
                    break;
                case "Nov":
                    tDays = 10*MONTH_DAYS+days;
                    break;
                case "Dec":
                    tDays = 11*MONTH_DAYS+days;
                    break;
            }
            d = (String) cb4.getSelectedItem();
            days2 = (int) cb5.getSelectedItem();
            switch(d)
            {
                case "Jan":
                    fDays = 0*MONTH_DAYS+days2;
                    break;
                case "Feb":
                    fDays = 1*MONTH_DAYS+days2;
                    break;
                case "Mar":
                    fDays = 2*MONTH_DAYS+days2;
                    break;
                case "Apr":
                    fDays = 3*MONTH_DAYS+days2;
                    break;
                case "May":
                    fDays = 4*MONTH_DAYS+days2;
                    break;
                case "Jun":
                    fDays = 5*MONTH_DAYS+days2;
                    break;
                case "Jul":
                    fDays = 6*MONTH_DAYS+days2;
                    break;
                case "Aug":
                    fDays = 7*MONTH_DAYS+days2;
                    break;
                case "Sep":
                    fDays = 8*MONTH_DAYS+days2;
                    break;
                case "Oct":
                    fDays = 9*MONTH_DAYS+days2;
                    break;
                case "Nov":
                    fDays = 10*MONTH_DAYS+days2;
                    break;
                case "Dec":
                    fDays = 11*MONTH_DAYS+days2;
                    break;
                //fDays (dropoff) - tDays (pickup) = totalrentdays <<<< totalrentdays*rentfeee (sasakyan)
            }
            g = name.getText();
            hiv = contacts.getText();
            if (model.equals(""))
            {
                z += 1;
                JOptionPane.showMessageDialog(null,"Please Pick A Car","Error",JOptionPane.WARNING_MESSAGE);
            }
            if (tDays >= fDays)
            {
                z += 1;
                JOptionPane.showMessageDialog(null,"Pickup Date Cant Be Greater than Dropoff Date","Error",JOptionPane.WARNING_MESSAGE);
            } else {
                total = fDays - tDays;
            }
            if (g.equals(""))
            {
                z += 1;
                JOptionPane.showMessageDialog(null,"Please Enter Your Name","Error",JOptionPane.WARNING_MESSAGE);
            }
            if (hiv.equals(""))
            {
                z += 1;
                JOptionPane.showMessageDialog(null,"Please Enter Your Contact Number","Error",JOptionPane.WARNING_MESSAGE);
            }
            infos.setInfo(g,hiv,a,b,days,days2,total);
            //System.out.println(infos.getName()+" "+total);
            if (z < 1)
            {
                int option = JOptionPane.showConfirmDialog(f,"Are you sure you about your choice?\nSelected: "+model+"\nRate: "+rate,"Prompt",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
                if(option == 0) {
                    total_fee = rate*total;
                    JOptionPane.showMessageDialog(null,"Thank you "+infos.getName()+" for renting "+model+".\nYour total rent fee is Php "+total_fee+".\nPlease Pick Up the Vehicle at "+infos.getPLoc()+"\nand return at "+infos.getDLoc()+" on "+d+" "+days2+".","Thank You",JOptionPane.PLAIN_MESSAGE);
                    this.dispose();
                    new UI().show();
                 }
                 else if (option == 1){
                    //Good day po di po namin alam ilalagay dito hehe
                }
            }
            z = 0;
        }
    }
}