import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class View extends JFrame implements ActionListener
{
    JButton aidslol = new JButton("Press for free robux");
    JLabel title = new JLabel("Available Cars:");
    Container p = getContentPane();
    GridBagConstraints gc = new GridBagConstraints();
    
    ImageIcon card = new ImageIcon("D:/Group 2 - Car Rental System/Images/Car1.jpg");
    JButton c1 = new JButton(card);
    ImageIcon card1 = new ImageIcon("D:/Group 2 - Car Rental System/Images/Car5.jpg");
    JButton c2 = new JButton(card1);
    ImageIcon card2 = new ImageIcon("D:/Group 2 - Car Rental System/Images/Car7.jpg");
    JButton c3 = new JButton(card2);
    ImageIcon card3 = new ImageIcon("D:/Group 2 - Car Rental System/Images/Car8.jpg");
    JButton c4 = new JButton(card3);
    JButton back = new JButton("Back");
    
    JLabel details = new JLabel("Vehicle Details");
    JTextArea carDetails = new JTextArea(7,25);
    JTextArea carDetails1 = new JTextArea(6,25);
    
    Info infos = new Info();
    Rent aids = new Rent();
    public View()
    {
        setTitle("Car Rental System");
        p.setLayout(new GridBagLayout());
        setBounds(0,0,900,450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        gc.fill = GridBagConstraints.BOTH;
        gc.insets = new Insets(5,5,5,5);
        gc.gridx = 0;
        gc.gridy = 0;
        title.setFont(title.getFont().deriveFont(35.0f));
        p.add(title,gc);
        gc.gridy = 1;
        p.add(c1,gc);
        gc.gridx = 1;
        p.add(c2,gc);
        gc.gridx = 0;
        gc.gridy = 2;
        p.add(c3,gc);
        gc.gridx = 1;
        p.add(c4,gc);
        gc.gridx = 2;
        gc.gridy = 0;
        details.setFont(title.getFont().deriveFont(35.0f));
        p.add(details,gc);
        gc.gridx = 2;
        gc.gridy = 1;
        carDetails.setEditable(false);
        carDetails.setText("Click on a Car\nfor more Details");
        p.add(carDetails,gc);
        gc.gridy = 2;
        carDetails1.setEditable(false);
        p.add(carDetails1,gc);
        gc.gridx = 0;
        gc.gridy = 3;
        p.add(back,gc);
        addActionEvent();
    }
    private void addActionEvent()
    {
        c1.addActionListener(this);
        c2.addActionListener(this);
        c3.addActionListener(this);
        c4.addActionListener(this);
        back.addActionListener(this);
    }
    public void actionPerformed(ActionEvent e) 
    {
        Object source = e.getSource();
        if (source == c1)
        {
            carDetails.setText("Model: Mitsubishi 3000GT (Lightning McQueen)\nYear Model: 1994\nCar Transmission: Manual\nFuel: Unleaded\nType: Sports Car\nPlate Number: 95\nColor: Red\nRental Price: Php 6,942.0");
            carDetails1.setText("Kachow! It's Lightning McQueen! This\nlife size replica of Lightning McQueen from the\nmovie 'Cars' will surely get lots of attention. \nMcQueen is built on a 1994 Mitsubishi 3000GT for\npotent V6 power and precise handling to go along\nwith the unique custom body kit.");
        } else if (source == c2)
        {
            carDetails1.setText("What you will like about the CX-5 is its fuel efficiency. \nAnother thing you might like is the driving\ndynamics of the vehicle. It gets\nits outstanding driving dynamics thanks to its\nchassis as well as the G-vectoring system\npresent in the vehicle.The vehicle also has exemplary\nbuild quality.");
            carDetails.setText("Model: Mazda CX-5\nYear Model: 2022\nCar Transmission: Matic\nFuel: Unleaded\nType: SUV\nPlate Number: ABC-420\nColor: Dark Grey\nRental Price: Php 4,400");
        } else if (source == c3)
        {
            carDetails1.setText("Road trip ready! This 12 passenger\nvan is perfect for longer trips.\nIt is also a good van for picking up children \nalong the way (iykyk).");
            carDetails.setText("Model: Chevrolet Express\nYear Model: 2020\nCar Transmission: Matic\nFuel: Diesel\nType: Passenger Van\nPlate Number: KDNPR-101\nColor: Yellow\nRental Price: Php 5,000");
        } else if (source == c4)
        {
            carDetails1.setText("This features dark design elements.\nThese include blacked-out 18-inch wheels, a\nblack grille, black exterior trim, black leather\nupholstery with red contrast stitching. \nMeanwhile, its red ambient lighting provides a colorful\nedge that gives the truck a little extra personality.");
            carDetails.setText("Model: Honda Ridgeline Sport\nYear Model: 2021\nCar Transmission: Matic\nFuel: Unleaded\nType: Pickup Truck\nPlate Number: DRGS-069\nColor: White\nRental Price: 3,750");
        } else if (source == back)
        {
            this.dispose();
            new UI().show();
        }
    }
}
